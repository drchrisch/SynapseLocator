# wekalab
A package for calling Weka functions from within Matlab
