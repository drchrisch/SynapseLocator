
function RUN_ALL

str = '  ====> PRESS RETURN <====  ';

example_2D_affine_nSpatialSamples
disp(str), pause

example_2D_affine_alpha
disp(str), pause

example_2D_warping
disp(str), pause

example_2D_affineThenWarping
disp(str), pause

example_2D_affineThenWarping_withParams

