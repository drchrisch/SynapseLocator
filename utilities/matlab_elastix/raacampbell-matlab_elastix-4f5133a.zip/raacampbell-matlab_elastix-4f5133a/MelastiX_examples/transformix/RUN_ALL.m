
function RUN_ALL

applyLenaTransform2Dog
disp('PRESS RETURN')
pause

%Note: the parameter files are slightly different here so you don't get quite the same image back
applyLenaTransform2Dog_withParams
disp('PRESS RETURN')
pause


transformSparsePoints_forward
